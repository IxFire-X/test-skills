# Разбор выживших мутантов — часть 1

Решение по каждой группе: TEST_GAP, SPEC_GAP, EQUIVALENT или OUT_OF_SCOPE (SKILL роли).

## Группы

### [MUT-0001] HelloWorldController#helloWorld, строка 16 (HelloWorldController.java)
[MUT-0001-1] ConditionalsBoundaryMutator: changed conditional boundary
[MUT-0001-2] RemoveConditionalMutator_ORDER_ELSE: removed conditional - replaced comparison check with false
Кейсы: TC-B1-011; требования: CREQ-B1-010, CREQ-B1-013, SREQ-0001, SREQ-0002, SREQ-0011, SREQ-0019
Код продукта (HelloWorldController.java):
[MUT-0001:L12]   
[MUT-0001:L13]       @GetMapping("/hello-world")
[MUT-0001:L14]       public String helloWorld(){
[MUT-0001:L15]           String greeting = "Hello World!";
[MUT-0001:L16] >         if (greeting.length() > 5) {
[MUT-0001:L17]               return greeting;
[MUT-0001:L18]           }
[MUT-0001:L19]           return "Hello World!";
[MUT-0001:L20]       }

### [MUT-0002] RequestCounterFilter#doFilterInternal, строка 22 (RequestCounterFilter.java)
[MUT-0002-1] MathMutator: Replaced long modulus with multiplication
[MUT-0002-2] RemoveConditionalMutator_EQUAL_ELSE: removed conditional - replaced equality check with false
Кейсы: TC-B1-001, TC-B1-002, TC-B1-003, TC-B1-004, TC-B1-005, TC-B1-006, TC-B1-007, TC-B1-008, TC-B1-009, TC-B1-010, TC-B1-011, TC-B1-012; требования: CREQ-B1-001, CREQ-B1-002, CREQ-B1-003, CREQ-B1-004, CREQ-B1-005, CREQ-B1-006, CREQ-B1-007, CREQ-B1-008, CREQ-B1-009, CREQ-B1-010, CREQ-B1-011, CREQ-B1-012, CREQ-B1-013, SREQ-0001, SREQ-0002, SREQ-0003, SREQ-0004, SREQ-0005, SREQ-0006, SREQ-0007, SREQ-0008, SREQ-0009, SREQ-0010, SREQ-0011, SREQ-0012, SREQ-0013, SREQ-0014, SREQ-0015, SREQ-0016, SREQ-0017, SREQ-0018, SREQ-0019, SREQ-0020
Код продукта (RequestCounterFilter.java):
[MUT-0002:L18]       @Override
[MUT-0002:L19]       protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
[MUT-0002:L20]               throws ServletException, IOException {
[MUT-0002:L21]           long count = requests.incrementAndGet();
[MUT-0002:L22] >         if (count % 1000 == 0) {
[MUT-0002:L23]               System.err.println("requests served: " + count);
[MUT-0002:L24]           }
[MUT-0002:L25]           chain.doFilter(request, response);
[MUT-0002:L26]       }

### [MUT-0003] StudentController#createStudent, строка 59 (StudentController.java)
[MUT-0003-1] VoidMethodCallMutator: removed call to java/io/PrintStream::println
Кейсы: TC-B1-007, TC-B1-008, TC-B1-012; требования: CREQ-B1-002, CREQ-B1-006, CREQ-B1-007, CREQ-B1-012, CREQ-B1-013, SREQ-0001, SREQ-0002, SREQ-0005, SREQ-0008, SREQ-0013, SREQ-0016, SREQ-0020
Код продукта (StudentController.java):
[MUT-0003:L55]   
[MUT-0003:L56]       @PostMapping("students/create")
[MUT-0003:L57]       @ResponseStatus(HttpStatus.CREATED)
[MUT-0003:L58]       public Student createStudent( @RequestBody Student student){
[MUT-0003:L59] >         System.out.println(student.getId());
[MUT-0003:L60]           System.out.println(student.getFirstName());
[MUT-0003:L61]           System.out.println(student.getLastName());
[MUT-0003:L62]           if (student.getFirstName() != null && student.getFirstName().length() > 40) {
[MUT-0003:L63]               student.setFirstName(student.getFirstName().substring(0, 40));

### [MUT-0004] StudentController#createStudent, строка 60 (StudentController.java)
[MUT-0004-1] VoidMethodCallMutator: removed call to java/io/PrintStream::println
Кейсы: TC-B1-007, TC-B1-008, TC-B1-012; требования: CREQ-B1-002, CREQ-B1-006, CREQ-B1-007, CREQ-B1-012, CREQ-B1-013, SREQ-0001, SREQ-0002, SREQ-0005, SREQ-0008, SREQ-0013, SREQ-0016, SREQ-0020
Код продукта (StudentController.java):
[MUT-0004:L56]       @PostMapping("students/create")
[MUT-0004:L57]       @ResponseStatus(HttpStatus.CREATED)
[MUT-0004:L58]       public Student createStudent( @RequestBody Student student){
[MUT-0004:L59]           System.out.println(student.getId());
[MUT-0004:L60] >         System.out.println(student.getFirstName());
[MUT-0004:L61]           System.out.println(student.getLastName());
[MUT-0004:L62]           if (student.getFirstName() != null && student.getFirstName().length() > 40) {
[MUT-0004:L63]               student.setFirstName(student.getFirstName().substring(0, 40));
[MUT-0004:L64]           }

### [MUT-0005] StudentController#createStudent, строка 61 (StudentController.java)
[MUT-0005-1] VoidMethodCallMutator: removed call to java/io/PrintStream::println
Кейсы: TC-B1-007, TC-B1-008, TC-B1-012; требования: CREQ-B1-002, CREQ-B1-006, CREQ-B1-007, CREQ-B1-012, CREQ-B1-013, SREQ-0001, SREQ-0002, SREQ-0005, SREQ-0008, SREQ-0013, SREQ-0016, SREQ-0020
Код продукта (StudentController.java):
[MUT-0005:L57]       @ResponseStatus(HttpStatus.CREATED)
[MUT-0005:L58]       public Student createStudent( @RequestBody Student student){
[MUT-0005:L59]           System.out.println(student.getId());
[MUT-0005:L60]           System.out.println(student.getFirstName());
[MUT-0005:L61] >         System.out.println(student.getLastName());
[MUT-0005:L62]           if (student.getFirstName() != null && student.getFirstName().length() > 40) {
[MUT-0005:L63]               student.setFirstName(student.getFirstName().substring(0, 40));
[MUT-0005:L64]           }
[MUT-0005:L65]           return student;

### [MUT-0006] StudentController#createStudent, строка 62 (StudentController.java)
[MUT-0006-1] ConditionalsBoundaryMutator: changed conditional boundary
[MUT-0006-2] RemoveConditionalMutator_EQUAL_ELSE: removed conditional - replaced equality check with false
[MUT-0006-3] RemoveConditionalMutator_ORDER_ELSE: removed conditional - replaced comparison check with false
Кейсы: TC-B1-007, TC-B1-008, TC-B1-012; требования: CREQ-B1-002, CREQ-B1-006, CREQ-B1-007, CREQ-B1-012, CREQ-B1-013, SREQ-0001, SREQ-0002, SREQ-0005, SREQ-0008, SREQ-0013, SREQ-0016, SREQ-0020
Код продукта (StudentController.java):
[MUT-0006:L58]       public Student createStudent( @RequestBody Student student){
[MUT-0006:L59]           System.out.println(student.getId());
[MUT-0006:L60]           System.out.println(student.getFirstName());
[MUT-0006:L61]           System.out.println(student.getLastName());
[MUT-0006:L62] >         if (student.getFirstName() != null && student.getFirstName().length() > 40) {
[MUT-0006:L63]               student.setFirstName(student.getFirstName().substring(0, 40));
[MUT-0006:L64]           }
[MUT-0006:L65]           return student;
[MUT-0006:L66]       }

### [MUT-0007] StudentController#deleteStudent, строка 81 (StudentController.java)
[MUT-0007-1] VoidMethodCallMutator: removed call to java/io/PrintStream::println
Кейсы: TC-B1-010; требования: CREQ-B1-009, CREQ-B1-013, SREQ-0001, SREQ-0002, SREQ-0010, SREQ-0018
Код продукта (StudentController.java):
[MUT-0007:L77]       // byuing @DeleteMappping Annotation
[MUT-0007:L78]   
[MUT-0007:L79]       @DeleteMapping("students/{id}/delete")
[MUT-0007:L80]        public  String deleteStudent(@PathVariable int id ){
[MUT-0007:L81] >          System.out.println(id);
[MUT-0007:L82]           return  "Student Successfully Deleted!";
[MUT-0007:L83]        }
[MUT-0007:L84]   }
[MUT-0007:L85]   

### [MUT-0008] StudentController#getStudent, строка 21 (StudentController.java)
[MUT-0008-1] NullReturnValsMutator: replaced return value with null for net/javaguides/springboot/controller/StudentController::getStudent
Кейсы: TC-B1-001; требования: CREQ-B1-001, CREQ-B1-011, CREQ-B1-013, SREQ-0001, SREQ-0002, SREQ-0003, SREQ-0004, SREQ-0012
Код продукта (StudentController.java):
[MUT-0008:L17]                   1,
[MUT-0008:L18]                   "Ramseh",
[MUT-0008:L19]                   "Mishra"
[MUT-0008:L20]           );
[MUT-0008:L21] >         return student ;
[MUT-0008:L22]       }
[MUT-0008:L23]       //http://localhost:8080/students
[MUT-0008:L24]   
[MUT-0008:L25]   @GetMapping("students")

### [MUT-0009] StudentController#updateStudent, строка 72 (StudentController.java)
[MUT-0009-1] VoidMethodCallMutator: removed call to java/io/PrintStream::println
Кейсы: TC-B1-009; требования: CREQ-B1-008, CREQ-B1-013, SREQ-0001, SREQ-0002, SREQ-0009, SREQ-0017
Код продукта (StudentController.java):
[MUT-0009:L68]       // Spring Boot REST API that handles  HTTP PUT Request ----- updating existing resource
[MUT-0009:L69]       //@PutMapping
[MUT-0009:L70]   @PutMapping("students/{id}/update")
[MUT-0009:L71]       public Student updateStudent(@RequestBody  Student student, @PathVariable int id){
[MUT-0009:L72] >         System.out.println(student.getFirstName());
[MUT-0009:L73]           System.out.println(student.getLastName());
[MUT-0009:L74]           return student;
[MUT-0009:L75]       }
[MUT-0009:L76]   // Spring Boot REST API that handles  HTTP Delete Request -------- Delete existing recourse

### [MUT-0010] StudentController#updateStudent, строка 73 (StudentController.java)
[MUT-0010-1] VoidMethodCallMutator: removed call to java/io/PrintStream::println
Кейсы: TC-B1-009; требования: CREQ-B1-008, CREQ-B1-013, SREQ-0001, SREQ-0002, SREQ-0009, SREQ-0017
Код продукта (StudentController.java):
[MUT-0010:L69]       //@PutMapping
[MUT-0010:L70]   @PutMapping("students/{id}/update")
[MUT-0010:L71]       public Student updateStudent(@RequestBody  Student student, @PathVariable int id){
[MUT-0010:L72]           System.out.println(student.getFirstName());
[MUT-0010:L73] >         System.out.println(student.getLastName());
[MUT-0010:L74]           return student;
[MUT-0010:L75]       }
[MUT-0010:L76]   // Spring Boot REST API that handles  HTTP Delete Request -------- Delete existing recourse
[MUT-0010:L77]       // byuing @DeleteMappping Annotation

## Кейсы

[TC-B1-001] Получение фиксированного студента по GET /student
  requirements: CREQ-B1-001, CREQ-B1-011, CREQ-B1-013
  objective: Убедиться, что эндпоинт отдаёт заранее заданного студента в формате JSON, включая закреплённое в требовании написание имени «Ramseh».
  pre: Приложение springboot-rest-api поднято в тестовом контексте Spring Boot (MockMvc), внешние сервисы и база данных не требуются.
  [STEP-B1-001-01] action: Отправить запрос GET /student.
    call: CAP-B1-mockmvc_exchange
    [INPUT-B1-001-01-1] arg:method = "GET" :string
    [INPUT-B1-001-01-2] arg:path = "/student" :string
    [EXP-B1-001-01-1] expected: Приложение возвращает одного студента с фиксированными значениями; поля в теле идут в порядке id, firstName, lastName.
      | 
      | HTTP 200 OK
      | Content-Type: application/json
      | {
      |   "id": 1,
      |   "firstName": "Ramseh",
      |   "lastName": "Mishra"
      | }
      [ASSERT-B1-001-01-1-1] project_result:status equals 200
      [ASSERT-B1-001-01-1-2] project_result:contentType equals "application/json"
      [ASSERT-B1-001-01-1-3] project_result:jsonObject equals {"firstName":"Ramseh","id":1,"lastName":"Mishra"}
      [ASSERT-B1-001-01-1-4] project_result:text equals "{\"id\":1,\"firstName\":\"Ramseh\",\"lastName\":\"Mishra\"}"
[TC-B1-002] Получение списка из четырёх студентов по GET /students
  requirements: CREQ-B1-002, CREQ-B1-013
  objective: Убедиться, что список содержит ровно четырёх студентов с идентификаторами 1..4 в заданном порядке и с заданными именами.
  pre: Приложение springboot-rest-api поднято в тестовом контексте Spring Boot (MockMvc), внешние сервисы и база данных не требуются.
  [STEP-B1-002-01] action: Отправить запрос GET /students.
    call: CAP-B1-mockmvc_exchange
    [INPUT-B1-002-01-1] arg:method = "GET" :string
    [INPUT-B1-002-01-2] arg:path = "/students" :string
    [EXP-B1-002-01-1] expected: Приложение возвращает JSON-массив из четырёх студентов в порядке идентификаторов 1, 2, 3, 4.
      | 
      | HTTP 200 OK
      | Content-Type: application/json
      | [
      |   {
      |     "id": 1,
      |     "firstName": "Ramesh",
      |     "lastName": "Mishra"
      |   },
      |   {
      |     "id": 2,
      |     "firstName": "Umesh",
      |     "lastName": "Mishra"
      |   },
      |   {
      |     "id": 3,
      |     "firstName": "Ram",
      |     "lastName": "Mishra"
      |   },
      |   {
      |     "id": 4,
      |     "firstName": "Sanjay",
      |     "lastName": "Mishra"
      |   }
      | ]
      [ASSERT-B1-002-01-1-1] project_result:status equals 200
      [ASSERT-B1-002-01-1-2] project_result:contentType equals "application/json"
      [ASSERT-B1-002-01-1-3] project_result:jsonArray length_equals 4
      [ASSERT-B1-002-01-1-4] project_result:jsonArray equals [{"firstName":"Ramesh","id":1,"lastName":"Mishra"},{"firstName":"Umesh","id":2,"lastName":"Mishra"},{"firstName":"Ram","id":3,"lastName":"Mishra"},{"firstName":"Sanjay","id":4,"lastName":"Mishra"}]
[TC-B1-003] Получение студента по идентификатору из пути GET /students/5
  requirements: CREQ-B1-003, CREQ-B1-013
  objective: Убедиться, что идентификатор из пути попадает в ответ вместе с закреплённым именем «Ramsesh».
  pre: Приложение springboot-rest-api поднято в тестовом контексте Spring Boot (MockMvc), внешние сервисы и база данных не требуются.
  [STEP-B1-003-01] action: Отправить запрос GET /students/5.
    call: CAP-B1-mockmvc_exchange
    [INPUT-B1-003-01-1] arg:method = "GET" :string
    [INPUT-B1-003-01-2] arg:path = "/students/5" :string
    [EXP-B1-003-01-1] expected: Приложение возвращает студента с идентификатором 5 из пути.
      | 
      | HTTP 200 OK
      | {
      |   "id": 5,
      |   "firstName": "Ramsesh",
      |   "lastName": "Mishra"
      | }
      [ASSERT-B1-003-01-1-1] project_result:status equals 200
      [ASSERT-B1-003-01-1-2] project_result:jsonObject equals {"firstName":"Ramsesh","id":5,"lastName":"Mishra"}
[TC-B1-004] Получение студента по идентификатору 0 из пути GET /students/0
  requirements: CREQ-B1-003, CREQ-B1-013
  objective: Убедиться, что граничное целое значение 0 принимается и возвращается без проверки существования студента.
  pre: Приложение springboot-rest-api поднято в тестовом контексте Spring Boot (MockMvc), внешние сервисы и база данных не требуются.
  [STEP-B1-004-01] action: Отправить запрос GET /students/0.
    call: CAP-B1-mockmvc_exchange
    [INPUT-B1-004-01-1] arg:method = "GET" :string
    [INPUT-B1-004-01-2] arg:path = "/students/0" :string
    [EXP-B1-004-01-1] expected: Приложение возвращает студента с идентификатором 0, не проверяя его существование.
      | 
      | HTTP 200 OK
      | {
      |   "id": 0,
      |   "firstName": "Ramsesh",
      |   "lastName": "Mishra"
      | }
      [ASSERT-B1-004-01-1-1] project_result:status equals 200
      [ASSERT-B1-004-01-1-2] project_result:jsonObject equals {"firstName":"Ramsesh","id":0,"lastName":"Mishra"}
[TC-B1-005] Получение студента по query-параметру GET /students/query?id=7
  requirements: CREQ-B1-004, CREQ-B1-013
  objective: Убедиться, что значение query-параметра id попадает в ответ вместе с закреплённым именем «Ramesh».
  pre: Приложение springboot-rest-api поднято в тестовом контексте Spring Boot (MockMvc), внешние сервисы и база данных не требуются.
  [STEP-B1-005-01] action: Отправить запрос GET /students/query с параметром id.
    call: CAP-B1-mockmvc_exchange
    [INPUT-B1-005-01-1] arg:method = "GET" :string
    [INPUT-B1-005-01-2] arg:path = "/students/query" :string
    [INPUT-B1-005-01-3] arg:query = {"id":"7"} :object
    [EXP-B1-005-01-1] expected: Приложение возвращает студента с идентификатором 7 из параметра запроса.
      | 
      | HTTP 200 OK
      | {
      |   "id": 7,
      |   "firstName": "Ramesh",
      |   "lastName": "Mishra"
      | }
      [ASSERT-B1-005-01-1-1] project_result:status equals 200
      [ASSERT-B1-005-01-1-2] project_result:jsonObject equals {"firstName":"Ramesh","id":7,"lastName":"Mishra"}
[TC-B1-006] Отказ в запросе студента без обязательного параметра id GET /students/query
  requirements: CREQ-B1-005, CREQ-B1-013
  objective: Убедиться, что отсутствие обязательного параметра id приводит к ошибке клиента, а не к ответу со студентом.
  pre: Приложение springboot-rest-api поднято в тестовом контексте Spring Boot (MockMvc), внешние сервисы и база данных не требуются.
  [STEP-B1-006-01] action: Отправить запрос GET /students/query без параметра id.
    call: CAP-B1-mockmvc_exchange
    [INPUT-B1-006-01-1] arg:method = "GET" :string
    [INPUT-B1-006-01-2] arg:path = "/students/query" :string
    [INPUT-B1-006-01-3] arg:query = {} :object
    [EXP-B1-006-01-1] expected: Приложение отклоняет запрос как некорректный; студент не возвращается.
      | 
      | HTTP 400 Bad Request
      [ASSERT-B1-006-01-1-1] project_result:status equals 400
[TC-B1-007] Создание студента с полным JSON-телом POST /students/create
  requirements: CREQ-B1-006, CREQ-B1-013
  objective: Убедиться, что полностью заполненное тело принимается со статусом 201 и возвращается без изменений.
  pre: Приложение springboot-rest-api поднято в тестовом контексте Spring Boot (MockMvc), внешние сервисы и база данных не требуются.
  [STEP-B1-007-01] action: Отправить запрос POST /students/create с JSON-телом студента.
    call: CAP-B1-mockmvc_exchange
    [INPUT-B1-007-01-1] arg:method = "POST" :string
    [INPUT-B1-007-01-2] arg:path = "/students/create" :string
    [INPUT-B1-007-01-3] arg:jsonBody = {"firstName":"Ivan","id":5,"lastName":"Petrov"} :object
    [EXP-B1-007-01-1] expected: Приложение подтверждает создание и возвращает тот же объект, что был отправлен.
      | 
      | HTTP 201 Created
      | {
      |   "id": 5,
      |   "firstName": "Ivan",
      |   "lastName": "Petrov"
      | }
      [ASSERT-B1-007-01-1-1] project_result:status equals 201
      [ASSERT-B1-007-01-1-2] project_result:jsonObject equals {"firstName":"Ivan","id":5,"lastName":"Petrov"}
[TC-B1-008] Создание студента с частично заполненным телом без lastName POST /students/create
  requirements: CREQ-B1-007, CREQ-B1-013
  objective: Убедиться, что отсутствующее поле lastName не мешает созданию и возвращается как null.
  pre: Приложение springboot-rest-api поднято в тестовом контексте Spring Boot (MockMvc), внешние сервисы и база данных не требуются.
  [STEP-B1-008-01] action: Отправить запрос POST /students/create с JSON-телом без поля lastName.
    call: CAP-B1-mockmvc_exchange
    [INPUT-B1-008-01-1] arg:method = "POST" :string
    [INPUT-B1-008-01-2] arg:path = "/students/create" :string
    [INPUT-B1-008-01-3] arg:jsonBody = {"firstName":"Olga","id":6} :object
    [EXP-B1-008-01-1] expected: Приложение подтверждает создание; в ответе поле lastName равно null, остальные поля повторяют запрос.
      | 
      | HTTP 201 Created
      | {
      |   "id": 6,
      |   "firstName": "Olga",
      |   "lastName": null
      | }
      [ASSERT-B1-008-01-1-1] project_result:status equals 201
      [ASSERT-B1-008-01-1-2] project_result:jsonObject equals {"firstName":"Olga","id":6,"lastName":null}
[TC-B1-009] Обновление студента по PUT /students/10/update возвращает тело запроса без подстановки id из пути
  requirements: CREQ-B1-008, CREQ-B1-013
  objective: Убедиться, что ответ повторяет отправленное тело, а идентификатор из пути (10) не заменяет идентификатор из тела (42).
  pre: Приложение springboot-rest-api поднято в тестовом контексте Spring Boot (MockMvc), внешние сервисы и база данных не требуются.
  [STEP-B1-009-01] action: Отправить запрос PUT /students/10/update с JSON-телом студента, у которого id отличается от id в пути.
    call: CAP-B1-mockmvc_exchange
    [INPUT-B1-009-01-1] arg:method = "PUT" :string
    [INPUT-B1-009-01-2] arg:path = "/students/10/update" :string
    [INPUT-B1-009-01-3] arg:jsonBody = {"firstName":"Anna","id":42,"lastName":"Sidorova"} :object
    [EXP-B1-009-01-1] expected: Приложение возвращает отправленное тело без изменений: id остаётся 42, а не 10 из пути.
      | 
      | HTTP 200 OK
      | {
      |   "id": 42,
      |   "firstName": "Anna",
      |   "lastName": "Sidorova"
      | }
      [ASSERT-B1-009-01-1-1] project_result:status equals 200
      [ASSERT-B1-009-01-1-2] project_result:jsonObject equals {"firstName":"Anna","id":42,"lastName":"Sidorova"}
[TC-B1-010] Удаление студента по DELETE /students/3/delete возвращает подтверждающий текст
  requirements: CREQ-B1-009, CREQ-B1-013
  objective: Убедиться, что запрос на удаление принимается и возвращает фиксированное текстовое сообщение.
  pre: Приложение springboot-rest-api поднято в тестовом контексте Spring Boot (MockMvc), внешние сервисы и база данных не требуются.
  [STEP-B1-010-01] action: Отправить запрос DELETE /students/3/delete.
    call: CAP-B1-mockmvc_exchange
    [INPUT-B1-010-01-1] arg:method = "DELETE" :string
    [INPUT-B1-010-01-2] arg:path = "/students/3/delete" :string
    [EXP-B1-010-01-1] expected: Приложение возвращает текст подтверждения удаления.
      | 
      | HTTP 200 OK
      | Student Successfully Deleted!
      [ASSERT-B1-010-01-1-1] project_result:status equals 200
      [ASSERT-B1-010-01-1-2] project_result:text equals "Student Successfully Deleted!"
[TC-B1-011] Получение приветствия по GET /hello-world
  requirements: CREQ-B1-010, CREQ-B1-013
  objective: Убедиться, что эндпоинт приветствия отвечает фиксированным текстом.
  pre: Приложение springboot-rest-api поднято в тестовом контексте Spring Boot (MockMvc), внешние сервисы и база данных не требуются.
  [STEP-B1-011-01] action: Отправить запрос GET /hello-world.
    call: CAP-B1-mockmvc_exchange
    [INPUT-B1-011-01-1] arg:method = "GET" :string
    [INPUT-B1-011-01-2] arg:path = "/hello-world" :string
    [EXP-B1-011-01-1] expected: Приложение возвращает текст приветствия.
      | 
      | HTTP 200 OK
      | Hello World!
      [ASSERT-B1-011-01-1-1] project_result:status equals 200
      [ASSERT-B1-011-01-1-2] project_result:text equals "Hello World!"
[TC-B1-012] Неизменность списка студентов после создания студента
  requirements: CREQ-B1-002, CREQ-B1-012, CREQ-B1-013
  objective: Убедиться, что создание студента не сохраняется: список GET /students после POST остаётся прежним, а повторный запрос списка даёт тот же ответ.
  pre: Приложение springboot-rest-api поднято в тестовом контексте Spring Boot (MockMvc), внешние сервисы и база данных не требуются.
  [STEP-B1-012-01] action: Отправить запрос POST /students/create с JSON-телом нового студента.
    call: CAP-B1-mockmvc_exchange
    [INPUT-B1-012-01-1] arg:method = "POST" :string
    [INPUT-B1-012-01-2] arg:path = "/students/create" :string
    [INPUT-B1-012-01-3] arg:jsonBody = {"firstName":"Pavel","id":9,"lastName":"Orlov"} :object
    [EXP-B1-012-01-1] expected: Приложение подтверждает создание и возвращает отправленный объект.
      | 
      | HTTP 201 Created
      | {
      |   "id": 9,
      |   "firstName": "Pavel",
      |   "lastName": "Orlov"
      | }
      [ASSERT-B1-012-01-1-1] project_result:status equals 201
      [ASSERT-B1-012-01-1-2] project_result:jsonObject equals {"firstName":"Pavel","id":9,"lastName":"Orlov"}
  [STEP-B1-012-02] action: Отправить запрос GET /students после создания.
    call: CAP-B1-mockmvc_exchange
    [INPUT-B1-012-02-1] arg:method = "GET" :string
    [INPUT-B1-012-02-2] arg:path = "/students" :string
    [EXP-B1-012-02-1] expected: Список студентов не изменился: те же четыре студента с идентификаторами 1..4, созданный студент с id 9 в списке отсутствует.
      | 
      | HTTP 200 OK
      | [
      |   {
      |     "id": 1,
      |     "firstName": "Ramesh",
      |     "lastName": "Mishra"
      |   },
      |   {
      |     "id": 2,
      |     "firstName": "Umesh",
      |     "lastName": "Mishra"
      |   },
      |   {
      |     "id": 3,
      |     "firstName": "Ram",
      |     "lastName": "Mishra"
      |   },
      |   {
      |     "id": 4,
      |     "firstName": "Sanjay",
      |     "lastName": "Mishra"
      |   }
      | ]
      [ASSERT-B1-012-02-1-1] project_result:status equals 200
      [ASSERT-B1-012-02-1-2] project_result:jsonArray equals [{"firstName":"Ramesh","id":1,"lastName":"Mishra"},{"firstName":"Umesh","id":2,"lastName":"Mishra"},{"firstName":"Ram","id":3,"lastName":"Mishra"},{"firstName":"Sanjay","id":4,"lastName":"Mishra"}]
  [STEP-B1-012-03] action: Повторно отправить запрос GET /students.
    call: CAP-B1-mockmvc_exchange
    [INPUT-B1-012-03-1] arg:method = "GET" :string
    [INPUT-B1-012-03-2] arg:path = "/students" :string
    [EXP-B1-012-03-1] expected: Повторный запрос даёт тот же список из четырёх студентов.
      | 
      | HTTP 200 OK
      | [
      |   {
      |     "id": 1,
      |     "firstName": "Ramesh",
      |     "lastName": "Mishra"
      |   },
      |   {
      |     "id": 2,
      |     "firstName": "Umesh",
      |     "lastName": "Mishra"
      |   },
      |   {
      |     "id": 3,
      |     "firstName": "Ram",
      |     "lastName": "Mishra"
      |   },
      |   {
      |     "id": 4,
      |     "firstName": "Sanjay",
      |     "lastName": "Mishra"
      |   }
      | ]
      [ASSERT-B1-012-03-1-1] project_result:status equals 200
      [ASSERT-B1-012-03-1-2] project_result:jsonArray equals [{"firstName":"Ramesh","id":1,"lastName":"Mishra"},{"firstName":"Umesh","id":2,"lastName":"Mishra"},{"firstName":"Ram","id":3,"lastName":"Mishra"},{"firstName":"Sanjay","id":4,"lastName":"Mishra"}]

## Требования

[CREQ-B1-001] GET /student возвращает 200 OK, Content-Type application/json и тело ровно {"id": 1, "firstName": "Ramseh", "lastName": "Mishra"}; значение firstName «Ramseh» (с опечаткой) является ожидаемым.
  src: docs/requirements/student-controller.md — 3.1. GET `/student`; docs/requirements/student-controller.md — AC-1
[CREQ-B1-002] GET /students возвращает 200 OK и JSON-массив ровно из четырёх студентов в фиксированном порядке: (1, Ramesh, Mishra), (2, Umesh, Mishra), (3, Ram, Mishra), (4, Sanjay, Mishra).
  src: docs/requirements/student-controller.md — 3.2. GET `/students`; docs/requirements/student-controller.md — AC-2
[CREQ-B1-003] GET /students/{id} с целочисленным id возвращает 200 OK и объект {"id": <id>, "firstName": "Ramsesh", "lastName": "Mishra"} для любого переданного id; существование студента не проверяется.
  src: docs/requirements/student-controller.md — 3.3. GET `/students/{id}` (Path Variable); docs/requirements/student-controller.md — AC-3
[CREQ-B1-004] GET /students/query?id=<id> с целочисленным query-параметром id возвращает 200 OK и объект {"id": <id>, "firstName": "Ramesh", "lastName": "Mishra"}.
  src: docs/requirements/student-controller.md — 3.4. GET `/students/query?id={id}` (Request Param); docs/requirements/student-controller.md — AC-4
[CREQ-B1-005] GET /students/query без параметра id возвращает 400 Bad Request.
  src: docs/requirements/student-controller.md — 3.4. GET `/students/query?id={id}` (Request Param), строка «Ошибка: отсутствие параметра id → 400 Bad Request»
[CREQ-B1-006] POST /students/create с полным JSON-телом студента (id, firstName, lastName) возвращает 201 Created и тело, равное телу запроса.
  src: docs/requirements/student-controller.md — 3.5. POST `/students/create`; docs/requirements/student-controller.md — AC-5
[CREQ-B1-007] POST /students/create с частично заполненным JSON-телом (без lastName) возвращает 201 Created и тело, в котором отсутствующее поле lastName равно null.
  src: docs/requirements/student-controller.md — 3.5. POST `/students/create`, строка «Особенность: частично заполненный JSON …»
[CREQ-B1-008] PUT /students/{id}/update с JSON-телом студента возвращает 200 OK и тело запроса без изменений; id из пути в возвращаемый объект не подставляется, даже если отличается от id в теле.
  src: docs/requirements/student-controller.md — 3.6. PUT `/students/{id}/update`; docs/requirements/student-controller.md — AC-6
[CREQ-B1-009] DELETE /students/{id}/delete с целочисленным id возвращает 200 OK и текст «Student Successfully Deleted!».
  src: docs/requirements/student-controller.md — 3.7. DELETE `/students/{id}/delete`; docs/requirements/student-controller.md — AC-7
[CREQ-B1-010] GET /hello-world возвращает 200 OK и текст «Hello World!».
  src: docs/requirements/student-controller.md — 3.8. GET `/hello-world`; docs/requirements/student-controller.md — AC-8
[CREQ-B1-011] JSON-представление студента содержит ровно три поля в порядке id (целое число), firstName (строка), lastName (строка); порядок определяется сериализацией Jackson по геттерам.
  src: docs/requirements/student-controller.md — 2. Модель данных; src/main/java/net/javaguides/springboot/bean/Student.java — геттеры getId, getFirstName, getLastName
[CREQ-B1-012] Эндпоинты не хранят состояние: POST /students/create не изменяет ответ GET /students, а повторный одинаковый запрос даёт тот же ответ.
  src: docs/requirements/student-controller.md — 5. Ограничения и риски, строка «Эндпоинты не используют БД и не хранят состояние»; docs/requirements/student-controller.md — 1. Общее описание
[CREQ-B1-013] Проверки выполняются через тестовый стек проекта: JUnit 5 и MockMvc из spring-boot-starter-test, сборка и запуск Maven; это ограничение тестовой работы, а не поведение приложения.
  src: docs/requirements/student-controller.md — заголовок и список источников; docs/requirements/student-controller.md — 1. Общее описание, строка «Стек тестирования»; pom.xml — spring-boot-starter-test
[SREQ-0001] src: docs/requirements/student-controller.md — Аналитика: StudentController (независимый прогон run2); docs/requirements/student-controller.md — sha256:3c34a282e8c0e24da91120526a87c9ec8ea1d7b7d7b31292cd894966bc0e85e7
  text: # Аналитика: StudentController (независимый прогон run2)
    | 
    | > Источник: исходный код `src/main/java/net/javaguides/springboot/controller/StudentController.java`,
    | > `src/main/java/net/javaguides/springboot/bean/Student.java`,
    | > `src/main/java/net/javaguides/springboot/controller/HelloWorldController.java`,
    | > `pom.xml` (Spring Boot 3.4.2, Java 17).
[SREQ-0002] src: docs/requirements/student-controller.md — 1. Общее описание; docs/requirements/student-controller.md — sha256:3c34a282e8c0e24da91120526a87c9ec8ea1d7b7d7b31292cd894966bc0e85e7
  text: ## 1. Общее описание
    | 
    | Проект `springboot-rest-api` — демонстрационное REST API на Spring Boot. Модуль `StudentController`
    | предоставляет CRUD-подобные эндпоинты для ресурса `Student` (id, firstName, lastName),
    | а `HelloWorldController` — простой GET-эндпоинт.
    | 
    | Стек тестирования: `spring-boot-starter-test` (JUnit 5, MockMvc, AssertJ). Сборка — Maven (`mvn test`).
[SREQ-0003] src: docs/requirements/student-controller.md — 2. Модель данных; docs/requirements/student-controller.md — sha256:3c34a282e8c0e24da91120526a87c9ec8ea1d7b7d7b31292cd894966bc0e85e7
  text: ## 2. Модель данных
    | 
    | `Student` (`net.javaguides.springboot.bean.Student`):
    | 
    | | Поле | Тип | JSON |
    | |---|---|---|
    | | id | int | `"id"` |
    | | firstName | String | `"firstName"` |
    | | lastName | String | `"lastName"` |
    | 
    | Точный порядок полей JSON определяется сериализацией Jackson (по getter-методам):
    | `id`, `firstName`, `lastName`.
[SREQ-0004] src: docs/requirements/student-controller.md — 3.1. GET `/student`; docs/requirements/student-controller.md — sha256:3c34a282e8c0e24da91120526a87c9ec8ea1d7b7d7b31292cd894966bc0e85e7
  text: ### 3.1. GET `/student`
    | - Описание: возвращает один объект Student с фиксированными значениями.
    | - Параметры: нет.
    | - Ответ: `200 OK`, `Content-Type: application/json`.
    | - Тело: `{"id": 1, "firstName": "Ramseh", "lastName": "Mishra"}`.
    | - Примечание: в исходном коде firstName = `"Ramseh"` (с опечаткой), это важно для точной проверки.
[SREQ-0005] src: docs/requirements/student-controller.md — 3.2. GET `/students`; docs/requirements/student-controller.md — sha256:3c34a282e8c0e24da91120526a87c9ec8ea1d7b7d7b31292cd894966bc0e85e7
  text: ### 3.2. GET `/students`
    | - Описание: возвращает список из 4 студентов.
    | - Параметры: нет.
    | - Ответ: `200 OK`, JSON-массив из 4 элементов.
    | - Тело (детерминированный порядок):
    |   1. `{"id": 1, "firstName": "Ramesh", "lastName": "Mishra"}`
    |   2. `{"id": 2, "firstName": "Umesh", "lastName": "Mishra"}`
    |   3. `{"id": 3, "firstName": "Ram", "lastName": "Mishra"}`
    |   4. `{"id": 4, "firstName": "Sanjay", "lastName": "Mishra"}`
[SREQ-0006] src: docs/requirements/student-controller.md — 3.3. GET `/students/{id}` (Path Variable); docs/requirements/student-controller.md — sha256:3c34a282e8c0e24da91120526a87c9ec8ea1d7b7d7b31292cd894966bc0e85e7
  text: ### 3.3. GET `/students/{id}` (Path Variable)
    | - Описание: возвращает Student по идентификатору из пути.
    | - Параметры пути: `id` (int).
    | - Ответ: `200 OK`, тело `{"id": <id>, "firstName": "Ramsesh", "lastName": "Mishra"}`.
    | - Примечание: метод не проверяет существование — всегда возвращает объект с переданным id.
[SREQ-0007] src: docs/requirements/student-controller.md — 3.4. GET `/students/query?id={id}` (Request Param); docs/requirements/student-controller.md — sha256:3c34a282e8c0e24da91120526a87c9ec8ea1d7b7d7b31292cd894966bc0e85e7
  text: ### 3.4. GET `/students/query?id={id}` (Request Param)
    | - Описание: возвращает Student по query-параметру `id`.
    | - Query-параметры: `id` (int, обязательный).
    | - Ответ: `200 OK`, тело `{"id": <id>, "firstName": "Ramesh", "lastName": "Mishra"}`.
    | - Ошибка: отсутствие параметра `id` → `400 Bad Request` (Spring).
[SREQ-0008] src: docs/requirements/student-controller.md — 3.5. POST `/students/create`; docs/requirements/student-controller.md — sha256:3c34a282e8c0e24da91120526a87c9ec8ea1d7b7d7b31292cd894966bc0e85e7
  text: ### 3.5. POST `/students/create`
    | - Описание: принимает Student в теле запроса, логирует поля и возвращает его же.
    | - Тело запроса: `application/json` `{"id": int, "firstName": string, "lastName": string}`.
    | - Ответ: `201 Created` (аннотация `@ResponseStatus(HttpStatus.CREATED)`), тело — эхо запроса.
    | - Особенность: частично заполненный JSON (например, без lastName) даст `null` в соответствующем поле ответа.
[SREQ-0009] src: docs/requirements/student-controller.md — 3.6. PUT `/students/{id}/update`; docs/requirements/student-controller.md — sha256:3c34a282e8c0e24da91120526a87c9ec8ea1d7b7d7b31292cd894966bc0e85e7
  text: ### 3.6. PUT `/students/{id}/update`
    | - Описание: принимает Student в теле и id в пути, логирует имя/фамилию, возвращает тело.
    | - Параметры пути: `id` (int).
    | - Тело запроса: `application/json` Student.
    | - Ответ: `200 OK`, тело — эхо запроса.
    | - Примечание: id из пути НЕ подставляется в возвращаемый объект — возвращается тело как есть.
[SREQ-0010] src: docs/requirements/student-controller.md — 3.7. DELETE `/students/{id}/delete`; docs/requirements/student-controller.md — sha256:3c34a282e8c0e24da91120526a87c9ec8ea1d7b7d7b31292cd894966bc0e85e7
  text: ### 3.7. DELETE `/students/{id}/delete`
    | - Описание: логирует id и возвращает сообщение об удалении.
    | - Параметры пути: `id` (int).
    | - Ответ: `200 OK`, текст `Student Successfully Deleted!`.
[SREQ-0011] src: docs/requirements/student-controller.md — 3.8. GET `/hello-world`; docs/requirements/student-controller.md — sha256:3c34a282e8c0e24da91120526a87c9ec8ea1d7b7d7b31292cd894966bc0e85e7
  text: ### 3.8. GET `/hello-world`
    | - Описание: возвращает строку приветствия.
    | - Ответ: `200 OK`, текст `Hello World!`.
[SREQ-0012] src: docs/requirements/student-controller.md — - AC-1: GET `/student` возвращает 200 и JSON `{"id":1,"firstName":"Ramseh","lastName":"Mishra"}`; docs/requirements/student-controller.md — sha256:3c34a282e8c0e24da91120526a87c9ec8ea1d7b7d7b31292cd894966bc0e85e7
  text: - AC-1: GET `/student` возвращает 200 и JSON `{"id":1,"firstName":"Ramseh","lastName":"Mishra"}`.
[SREQ-0013] src: docs/requirements/student-controller.md — - AC-2: GET `/students` возвращает 200 и массив из 4 объектов с идентификаторами 1..4; docs/requirements/student-controller.md — sha256:3c34a282e8c0e24da91120526a87c9ec8ea1d7b7d7b31292cd894966bc0e85e7
  text: - AC-2: GET `/students` возвращает 200 и массив из 4 объектов с идентификаторами 1..4.
[SREQ-0014] src: docs/requirements/student-controller.md — - AC-3: GET `/students/5` возвращает 200 и объект с `id=5`, firstName `Ramsesh`; docs/requirements/student-controller.md — sha256:3c34a282e8c0e24da91120526a87c9ec8ea1d7b7d7b31292cd894966bc0e85e7
  text: - AC-3: GET `/students/5` возвращает 200 и объект с `id=5`, firstName `Ramsesh`.
[SREQ-0015] src: docs/requirements/student-controller.md — - AC-4: GET `/students/query?id=7` возвращает 200 и объект с `id=7`, firstName `Ramesh`; docs/requirements/student-controller.md — sha256:3c34a282e8c0e24da91120526a87c9ec8ea1d7b7d7b31292cd894966bc0e85e7
  text: - AC-4: GET `/students/query?id=7` возвращает 200 и объект с `id=7`, firstName `Ramesh`.
[SREQ-0016] src: docs/requirements/student-controller.md — - AC-5: POST `/students/create` с валидным JSON возвращает `201 Created` и эхо запроса; docs/requirements/student-controller.md — sha256:3c34a282e8c0e24da91120526a87c9ec8ea1d7b7d7b31292cd894966bc0e85e7
  text: - AC-5: POST `/students/create` с валидным JSON возвращает `201 Created` и эхо запроса.
[SREQ-0017] src: docs/requirements/student-controller.md — - AC-6: PUT `/students/10/update` с валидным JSON возвращает `200 OK` и эхо тела запроса; docs/requirements/student-controller.md — sha256:3c34a282e8c0e24da91120526a87c9ec8ea1d7b7d7b31292cd894966bc0e85e7
  text: - AC-6: PUT `/students/10/update` с валидным JSON возвращает `200 OK` и эхо тела запроса.
[SREQ-0018] src: docs/requirements/student-controller.md — - AC-7: DELETE `/students/3/delete` возвращает `200 OK` и текст `Student Successfully Deleted!`; docs/requirements/student-controller.md — sha256:3c34a282e8c0e24da91120526a87c9ec8ea1d7b7d7b31292cd894966bc0e85e7
  text: - AC-7: DELETE `/students/3/delete` возвращает `200 OK` и текст `Student Successfully Deleted!`.
[SREQ-0019] src: docs/requirements/student-controller.md — - AC-8: GET `/hello-world` возвращает `200 OK` и текст `Hello World!`; docs/requirements/student-controller.md — sha256:3c34a282e8c0e24da91120526a87c9ec8ea1d7b7d7b31292cd894966bc0e85e7
  text: - AC-8: GET `/hello-world` возвращает `200 OK` и текст `Hello World!`.
[SREQ-0020] src: docs/requirements/student-controller.md — 5. Ограничения и риски; docs/requirements/student-controller.md — sha256:3c34a282e8c0e24da91120526a87c9ec8ea1d7b7d7b31292cd894966bc0e85e7
  text: ## 5. Ограничения и риски
    | 
    | - Эндпоинты не используют БД и не хранят состояние: все ответы детерминированы кодом.
    | - Опечатка `"Ramseh"` в GET `/student` — намеренно фиксируется как ожидаемое значение, чтобы тест проверял фактическое поведение.
    | - Метод PUT не подставляет path-variable в объект — проверять именно эхо тела.
    | - Приложение стартует на стандартном порту 8080 (для MockMvc порт не требуется).

## Код тестов

Файл теста src/test/java/net/javaguides/springboot/controller/StudentControllerPipelineTest.java:
[T:L0043]     private MockHttpServletResponse exchange(String method, String path, Map<String, String> query,
[T:L0044]                                              Map<String, Object> jsonBody) throws Exception {
[T:L0045]         MockHttpServletRequestBuilder request = MockMvcRequestBuilders.request(HttpMethod.valueOf(method), path);
[T:L0046]         if (query != null) {
[T:L0047]             for (Map.Entry<String, String> entry : query.entrySet()) {
[T:L0048]                 request = request.queryParam(entry.getKey(), entry.getValue());
[T:L0049]             }
[T:L0050]         }
[T:L0051]         if (jsonBody != null) {
[T:L0052]             request = request.contentType(MediaType.APPLICATION_JSON)
[T:L0053]                     .content(objectMapper.writeValueAsString(jsonBody));
[T:L0054]         }
[T:L0055]         return mockMvc.perform(request).andReturn().getResponse();
[T:L0056]     }
…
[T:L0058]     private static String text(MockHttpServletResponse response) throws Exception {
[T:L0059]         return response.getContentAsString(StandardCharsets.UTF_8);
[T:L0060]     }
…
[T:L0062]     private Map<String, Object> jsonObject(MockHttpServletResponse response) throws Exception {
[T:L0063]         return objectMapper.readValue(text(response), new TypeReference<Map<String, Object>>() { });
[T:L0064]     }
…
[T:L0066]     private List<Map<String, Object>> jsonArray(MockHttpServletResponse response) throws Exception {
[T:L0067]         return objectMapper.readValue(text(response), new TypeReference<List<Map<String, Object>>>() { });
[T:L0068]     }
…
[T:L0070]     private static Map<String, Object> student(Integer id, String firstName, String lastName) {
[T:L0071]         Map<String, Object> student = new LinkedHashMap<>();
[T:L0072]         student.put("id", id);
[T:L0073]         student.put("firstName", firstName);
[T:L0074]         student.put("lastName", lastName);
[T:L0075]         return student;
[T:L0076]     }
…
[T:L0078]     private static List<Map<String, Object>> fourStudents() {
[T:L0079]         return List.of(
[T:L0080]                 student(1, "Ramesh", "Mishra"),
[T:L0081]                 student(2, "Umesh", "Mishra"),
[T:L0082]                 student(3, "Ram", "Mishra"),
[T:L0083]                 student(4, "Sanjay", "Mishra"));
[T:L0084]     }
…
[T:L0088]     @Test
[T:L0089]     @DisplayName("TC-B1-001 Получение фиксированного студента по GET /student")
[T:L0090]     void tcB1001GetStudentReturnsFixedStudent() throws Exception {
[T:L0091]         MockHttpServletResponse response = exchange("GET", "/student", null, null);
[T:L0092] 
[T:L0093]         assertThat(response.getStatus()).as("ASSERT-B1-001-01-1-1").isEqualTo(200);
[T:L0094]     }
…
[T:L0096]     @Test
[T:L0097]     @DisplayName("TC-B1-002 Получение списка из четырёх студентов по GET /students")
[T:L0098]     void tcB1002GetStudentsReturnsFourStudentsInOrder() throws Exception {
[T:L0099]         MockHttpServletResponse response = exchange("GET", "/students", null, null);
[T:L0100] 
[T:L0101]         assertThat(response.getStatus()).as("ASSERT-B1-002-01-1-1").isEqualTo(200);
[T:L0102]         assertThat(response.getContentType()).as("ASSERT-B1-002-01-1-2").isEqualTo(APPLICATION_JSON);
[T:L0103]         List<Map<String, Object>> students = jsonArray(response);
[T:L0104]         assertThat(students).as("ASSERT-B1-002-01-1-3").hasSize(4);
[T:L0105]         assertThat(students).as("ASSERT-B1-002-01-1-4").isEqualTo(fourStudents());
[T:L0106]     }
…
[T:L0108]     @Test
[T:L0109]     @DisplayName("TC-B1-003 Получение студента по идентификатору из пути GET /students/5")
[T:L0110]     void tcB1003GetStudentByPathVariableReturnsRequestedId() throws Exception {
[T:L0111]         MockHttpServletResponse response = exchange("GET", "/students/5", null, null);
[T:L0112] 
[T:L0113]         assertThat(response.getStatus()).as("ASSERT-B1-003-01-1-1").isEqualTo(200);
[T:L0114]         assertThat(jsonObject(response)).as("ASSERT-B1-003-01-1-2").isEqualTo(student(5, "Ramsesh", "Mishra"));
[T:L0115]     }
…
[T:L0117]     @Test
[T:L0118]     @DisplayName("TC-B1-004 Получение студента по идентификатору 0 из пути GET /students/0")
[T:L0119]     void tcB1004GetStudentByPathVariableZeroIsAccepted() throws Exception {
[T:L0120]         MockHttpServletResponse response = exchange("GET", "/students/0", null, null);
[T:L0121] 
[T:L0122]         assertThat(response.getStatus()).as("ASSERT-B1-004-01-1-1").isEqualTo(200);
[T:L0123]         assertThat(jsonObject(response)).as("ASSERT-B1-004-01-1-2").isEqualTo(student(0, "Ramsesh", "Mishra"));
[T:L0124]     }
…
[T:L0126]     @Test
[T:L0127]     @DisplayName("TC-B1-005 Получение студента по query-параметру GET /students/query?id=7")
[T:L0128]     void tcB1005GetStudentByQueryParameterReturnsRequestedId() throws Exception {
[T:L0129]         MockHttpServletResponse response = exchange("GET", "/students/query", Map.of("id", "7"), null);
[T:L0130] 
[T:L0131]         assertThat(response.getStatus()).as("ASSERT-B1-005-01-1-1").isEqualTo(200);
[T:L0132]         assertThat(jsonObject(response)).as("ASSERT-B1-005-01-1-2").isEqualTo(student(7, "Ramesh", "Mishra"));
[T:L0133]     }
…
[T:L0135]     @Test
[T:L0136]     @DisplayName("TC-B1-006 Отказ в запросе студента без обязательного параметра id GET /students/query")
[T:L0137]     void tcB1006GetStudentWithoutIdParameterIsBadRequest() throws Exception {
[T:L0138]         MockHttpServletResponse response = exchange("GET", "/students/query", Map.of(), null);
[T:L0139] 
[T:L0140]         assertThat(response.getStatus()).as("ASSERT-B1-006-01-1-1").isEqualTo(400);
[T:L0141]     }
…
[T:L0143]     @Test
[T:L0144]     @DisplayName("TC-B1-007 Создание студента с полным JSON-телом POST /students/create")
[T:L0145]     void tcB1007CreateStudentEchoesFullBodyWithCreated() throws Exception {
[T:L0146]         Map<String, Object> body = student(5, "Ivan", "Petrov");
[T:L0147] 
[T:L0148]         MockHttpServletResponse response = exchange("POST", "/students/create", null, body);
[T:L0149] 
[T:L0150]         assertThat(response.getStatus()).as("ASSERT-B1-007-01-1-1").isEqualTo(201);
[T:L0151]         assertThat(jsonObject(response)).as("ASSERT-B1-007-01-1-2").isEqualTo(student(5, "Ivan", "Petrov"));
[T:L0152]     }
…
[T:L0154]     @Test
[T:L0155]     @DisplayName("TC-B1-008 Создание студента с частично заполненным телом без lastName POST /students/create")
[T:L0156]     void tcB1008CreateStudentWithoutLastNameEchoesNull() throws Exception {
[T:L0157]         Map<String, Object> body = new LinkedHashMap<>();
[T:L0158]         body.put("id", 6);
[T:L0159]         body.put("firstName", "Olga");
[T:L0160] 
[T:L0161]         MockHttpServletResponse response = exchange("POST", "/students/create", null, body);
[T:L0162] 
[T:L0163]         assertThat(response.getStatus()).as("ASSERT-B1-008-01-1-1").isEqualTo(201);
[T:L0164]         assertThat(jsonObject(response)).as("ASSERT-B1-008-01-1-2").isEqualTo(student(6, "Olga", null));
[T:L0165]     }
…
[T:L0167]     @Test
[T:L0168]     @DisplayName("TC-B1-009 Обновление студента по PUT /students/10/update возвращает тело без подстановки id из пути")
[T:L0169]     void tcB1009UpdateStudentEchoesBodyWithoutPathId() throws Exception {
[T:L0170]         Map<String, Object> body = student(42, "Anna", "Sidorova");
[T:L0171] 
[T:L0172]         MockHttpServletResponse response = exchange("PUT", "/students/10/update", null, body);
[T:L0173] 
[T:L0174]         assertThat(response.getStatus()).as("ASSERT-B1-009-01-1-1").isEqualTo(200);
[T:L0175]         assertThat(jsonObject(response)).as("ASSERT-B1-009-01-1-2").isEqualTo(student(42, "Anna", "Sidorova"));
[T:L0176]     }
…
[T:L0178]     @Test
[T:L0179]     @DisplayName("TC-B1-010 Удаление студента по DELETE /students/3/delete возвращает подтверждающий текст")
[T:L0180]     void tcB1010DeleteStudentReturnsConfirmationText() throws Exception {
[T:L0181]         MockHttpServletResponse response = exchange("DELETE", "/students/3/delete", null, null);
[T:L0182] 
[T:L0183]         assertThat(response.getStatus()).as("ASSERT-B1-010-01-1-1").isEqualTo(200);
[T:L0184]         assertThat(text(response)).as("ASSERT-B1-010-01-1-2").isEqualTo("Student Successfully Deleted!");
[T:L0185]     }
…
[T:L0187]     @Test
[T:L0188]     @DisplayName("TC-B1-011 Получение приветствия по GET /hello-world")
[T:L0189]     void tcB1011HelloWorldReturnsGreeting() throws Exception {
[T:L0190]         MockHttpServletResponse response = exchange("GET", "/hello-world", null, null);
[T:L0191] 
[T:L0192]         assertThat(response.getStatus()).as("ASSERT-B1-011-01-1-1").isEqualTo(200);
[T:L0193]         assertThat(text(response)).as("ASSERT-B1-011-01-1-2").isEqualTo("Hello World!");
[T:L0194]     }
…
[T:L0196]     @Test
[T:L0197]     @DisplayName("TC-B1-012 Неизменность списка студентов после создания студента")
[T:L0198]     void tcB1012StudentListIsUnchangedAfterCreate() throws Exception {
[T:L0199]         // STEP-B1-012-01
[T:L0200]         MockHttpServletResponse created = exchange("POST", "/students/create", null, student(9, "Pavel", "Orlov"));
[T:L0201]         assertThat(created.getStatus()).as("ASSERT-B1-012-01-1-1").isEqualTo(201);
[T:L0202]         assertThat(jsonObject(created)).as("ASSERT-B1-012-01-1-2").isEqualTo(student(9, "Pavel", "Orlov"));
[T:L0203] 
[T:L0204]         // STEP-B1-012-02
[T:L0205]         MockHttpServletResponse afterCreate = exchange("GET", "/students", null, null);
[T:L0206]         assertThat(afterCreate.getStatus()).as("ASSERT-B1-012-02-1-1").isEqualTo(200);
[T:L0207]         assertThat(jsonArray(afterCreate)).as("ASSERT-B1-012-02-1-2").isEqualTo(fourStudents());
[T:L0208] 
[T:L0209]         // STEP-B1-012-03
[T:L0210]         MockHttpServletResponse repeated = exchange("GET", "/students", null, null);
[T:L0211]         assertThat(repeated.getStatus()).as("ASSERT-B1-012-03-1-1").isEqualTo(200);
[T:L0212]         assertThat(jsonArray(repeated)).as("ASSERT-B1-012-03-1-2").isEqualTo(fourStudents());
[T:L0213]     }
