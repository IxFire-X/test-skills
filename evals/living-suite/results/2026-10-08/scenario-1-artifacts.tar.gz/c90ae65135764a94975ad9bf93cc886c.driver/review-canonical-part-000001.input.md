# Ревью кейсов compact-v1 · TCDOC-step5-java-demo-9340016c r1 · part-000001 (1 из 1)

Инструкции контроллера: Проверь назначенные области этой части по исходным требованиям: полноту, корректность шагов и ожидаемых результатов, согласованность между кейсами. Верни только coverage, findings, corrections и required_checks.
Ответ: coverage — строка на каждую область ниже, в этом порядке (area_id, status CHECKED|UNCHECKED, refs — 1–3 якоря [ID] из этой части, у области кейса хотя бы один якорь самого кейса; строки исходника — SRC-n:Lk; note — до 200 символов). findings — severity, code, related_ids, message (до 600 символов; INFO не больше 5). corrections — target_id, field из словаря, before, after, why. lint_dispositions — по каждому [LINT-…] этой части. required_checks — case_ids/requirement_ids и reason.

## Области ответа
- source-000001 — исходник: каждое условие исходных требований ↔ SREQ ↔ CREQ, требования без кейсов, возможности и их источники.
- local-TC-B1-010 — кейс TC-B1-010: шаги, данные, вызовы и входы, ожидания и проверки против CREQ/SREQ и возможностей.
- local-TC-B1-013 — кейс TC-B1-013: шаги, данные, вызовы и входы, ожидания и проверки против CREQ/SREQ и возможностей.
- cross-8b1fe4b8782b47cc — связи между всеми кейсами этой части (2): одинаковые вызовы с разными ожиданиями, общее состояние, количество и полные списки ресурса, который меняют другие кейсы.

## Индекс всех кейсов документа
TC-B1-010 · CREQ-B1-009, CREQ-B1-013 · Удаление студента по DELETE /students/3/delete возвращает подтверждающий текст
TC-B1-013 · CREQ-B1-013, CREQ-B1-014 · Отказ в удалении студента с нечисловым идентификатором в пути DELETE /students/abc/delete

## Требования CREQ
[CREQ-B1-009] DELETE /students/{id}/delete с целочисленным id возвращает 200 OK и текст «Student deleted».
  src: docs/requirements/student-controller.md — 3.7. DELETE `/students/{id}/delete`; docs/requirements/student-controller.md — AC-7
[CREQ-B1-013] Проверки выполняются через тестовый стек проекта: JUnit 5 и MockMvc из spring-boot-starter-test, сборка и запуск Maven; это ограничение тестовой работы, а не поведение приложения.
  src: docs/requirements/student-controller.md — заголовок и список источников; docs/requirements/student-controller.md — 1. Общее описание, строка «Стек тестирования»; pom.xml — spring-boot-starter-test
[CREQ-B1-014] DELETE /students/{id}/delete с нечисловым идентификатором в пути (например, abc) возвращает 400 Bad Request.
  src: docs/requirements/student-controller.md — AC-9; docs/requirements/student-controller.md — 3.7. DELETE `/students/{id}/delete`, строка «Параметры пути: id (int)»

## Исходные требования (дословно, с номерами строк)
[SRC-1] docs/requirements/student-controller.md (95 строк)
L01| # Аналитика: StudentController (независимый прогон run2)
L02| 
L03| > Источник: исходный код `src/main/java/net/javaguides/springboot/controller/StudentController.java`,
L04| > `src/main/java/net/javaguides/springboot/bean/Student.java`,
L05| > `src/main/java/net/javaguides/springboot/controller/HelloWorldController.java`,
L06| > `pom.xml` (Spring Boot 3.4.2, Java 17).
L07| 
L08| ## 1. Общее описание
L09| 
L10| Проект `springboot-rest-api` — демонстрационное REST API на Spring Boot. Модуль `StudentController`
L11| предоставляет CRUD-подобные эндпоинты для ресурса `Student` (id, firstName, lastName),
L12| а `HelloWorldController` — простой GET-эндпоинт.
L13| 
L14| Стек тестирования: `spring-boot-starter-test` (JUnit 5, MockMvc, AssertJ). Сборка — Maven (`mvn test`).
L15| 
L16| ## 2. Модель данных
L17| 
L18| `Student` (`net.javaguides.springboot.bean.Student`):
L19| 
L20| | Поле | Тип | JSON |
L21| |---|---|---|
L22| | id | int | `"id"` |
L23| | firstName | String | `"firstName"` |
L24| | lastName | String | `"lastName"` |
L25| 
L26| Точный порядок полей JSON определяется сериализацией Jackson (по getter-методам):
L27| `id`, `firstName`, `lastName`.
L28| 
L29| ## 3. Перечень эндпоинтов и контракты API
L30| 
L31| ### 3.1. GET `/student`
L32| - Описание: возвращает один объект Student с фиксированными значениями.
L33| - Параметры: нет.
L34| - Ответ: `200 OK`, `Content-Type: application/json`.
L35| - Тело: `{"id": 1, "firstName": "Ramseh", "lastName": "Mishra"}`.
L36| - Примечание: в исходном коде firstName = `"Ramseh"` (с опечаткой), это важно для точной проверки.
L37| 
L38| ### 3.2. GET `/students`
L39| - Описание: возвращает список из 4 студентов.
L40| - Параметры: нет.
L41| - Ответ: `200 OK`, JSON-массив из 4 элементов.
L42| - Тело (детерминированный порядок):
L43|   1. `{"id": 1, "firstName": "Ramesh", "lastName": "Mishra"}`
L44|   2. `{"id": 2, "firstName": "Umesh", "lastName": "Mishra"}`
L45|   3. `{"id": 3, "firstName": "Ram", "lastName": "Mishra"}`
L46|   4. `{"id": 4, "firstName": "Sanjay", "lastName": "Mishra"}`
L47| 
L48| ### 3.3. GET `/students/{id}` (Path Variable)
L49| - Описание: возвращает Student по идентификатору из пути.
L50| - Параметры пути: `id` (int).
L51| - Ответ: `200 OK`, тело `{"id": <id>, "firstName": "Ramsesh", "lastName": "Mishra"}`.
L52| - Примечание: метод не проверяет существование — всегда возвращает объект с переданным id.
L53| 
L54| ### 3.4. GET `/students/query?id={id}` (Request Param)
L55| - Описание: возвращает Student по query-параметру `id`.
L56| - Query-параметры: `id` (int, обязательный).
L57| - Ответ: `200 OK`, тело `{"id": <id>, "firstName": "Ramesh", "lastName": "Mishra"}`.
L58| - Ошибка: отсутствие параметра `id` → `400 Bad Request` (Spring).
L59| 
L60| ### 3.5. POST `/students/create`
L61| - Описание: принимает Student в теле запроса, логирует поля и возвращает его же.
L62| - Тело запроса: `application/json` `{"id": int, "firstName": string, "lastName": string}`.
L63| - Ответ: `201 Created` (аннотация `@ResponseStatus(HttpStatus.CREATED)`), тело — эхо запроса.
L64| - Особенность: частично заполненный JSON (например, без lastName) даст `null` в соответствующем поле ответа.
L65| 
L66| ### 3.6. PUT `/students/{id}/update`
L67| - Описание: принимает Student в теле и id в пути, логирует имя/фамилию, возвращает тело.
L68| - Параметры пути: `id` (int).
L69| - Тело запроса: `application/json` Student.
L70| - Ответ: `200 OK`, тело — эхо запроса.
L71| - Примечание: id из пути НЕ подставляется в возвращаемый объект — возвращается тело как есть.
L72| 
L73| ### 3.7. DELETE `/students/{id}/delete`
L74| - Описание: логирует id и возвращает сообщение об удалении.
L75| - Параметры пути: `id` (int).
L76| - Ответ: `200 OK`, текст `Student deleted`.
L77| 
L78| 
L79| ## 4. Критерии приёмки (Acceptance Criteria)
L80| 
L81| - AC-1: GET `/student` возвращает 200 и JSON `{"id":1,"firstName":"Ramseh","lastName":"Mishra"}`.
L82| - AC-2: GET `/students` возвращает 200 и массив из 4 объектов с идентификаторами 1..4.
L83| - AC-3: GET `/students/5` возвращает 200 и объект с `id=5`, firstName `Ramsesh`.
L84| - AC-4: GET `/students/query?id=7` возвращает 200 и объект с `id=7`, firstName `Ramesh`.
L85| - AC-5: POST `/students/create` с валидным JSON возвращает `201 Created` и эхо запроса.
L86| - AC-6: PUT `/students/10/update` с валидным JSON возвращает `200 OK` и эхо тела запроса.
L87| - AC-9: DELETE `/students/abc/delete` с нечисловым идентификатором возвращает `400 Bad Request`.
L88| - AC-7: DELETE `/students/3/delete` возвращает `200 OK` и текст `Student deleted`.
L89| 
L90| ## 5. Ограничения и риски
L91| 
L92| - Эндпоинты не используют БД и не хранят состояние: все ответы детерминированы кодом.
L93| - Опечатка `"Ramseh"` в GET `/student` — намеренно фиксируется как ожидаемое значение, чтобы тест проверял фактическое поведение.
L94| - Метод PUT не подставляет path-variable в объект — проверять именно эхо тела.
L95| - Приложение стартует на стандартном порту 8080 (для MockMvc порт не требуется).

## SREQ — нормализованные исходные требования
[SREQ-0001] src: docs/requirements/student-controller.md — Аналитика: StudentController (независимый прогон run2); docs/requirements/student-controller.md — sha256:8f9b785d0669282b7a1681a7213226afd6230c97db4fe720e0cca80cb64afd85
  text: # Аналитика: StudentController (независимый прогон run2)
    | 
    | > Источник: исходный код `src/main/java/net/javaguides/springboot/controller/StudentController.java`,
    | > `src/main/java/net/javaguides/springboot/bean/Student.java`,
    | > `src/main/java/net/javaguides/springboot/controller/HelloWorldController.java`,
    | > `pom.xml` (Spring Boot 3.4.2, Java 17).
[SREQ-0002] src: docs/requirements/student-controller.md — 1. Общее описание; docs/requirements/student-controller.md — sha256:8f9b785d0669282b7a1681a7213226afd6230c97db4fe720e0cca80cb64afd85
  text: ## 1. Общее описание
    | 
    | Проект `springboot-rest-api` — демонстрационное REST API на Spring Boot. Модуль `StudentController`
    | предоставляет CRUD-подобные эндпоинты для ресурса `Student` (id, firstName, lastName),
    | а `HelloWorldController` — простой GET-эндпоинт.
    | 
    | Стек тестирования: `spring-boot-starter-test` (JUnit 5, MockMvc, AssertJ). Сборка — Maven (`mvn test`).
[SREQ-0010] src: docs/requirements/student-controller.md — 3.7. DELETE `/students/{id}/delete`; docs/requirements/student-controller.md — sha256:8f9b785d0669282b7a1681a7213226afd6230c97db4fe720e0cca80cb64afd85
  text: ### 3.7. DELETE `/students/{id}/delete`
    | - Описание: логирует id и возвращает сообщение об удалении.
    | - Параметры пути: `id` (int).
    | - Ответ: `200 OK`, текст `Student deleted`.
[SREQ-0017] src: docs/requirements/student-controller.md — - AC-9: DELETE `/students/abc/delete` с нечисловым идентификатором возвращает `400 Bad Request`; docs/requirements/student-controller.md — sha256:8f9b785d0669282b7a1681a7213226afd6230c97db4fe720e0cca80cb64afd85
  text: - AC-9: DELETE `/students/abc/delete` с нечисловым идентификатором возвращает `400 Bad Request`.
[SREQ-0018] src: docs/requirements/student-controller.md — - AC-7: DELETE `/students/3/delete` возвращает `200 OK` и текст `Student deleted`; docs/requirements/student-controller.md — sha256:8f9b785d0669282b7a1681a7213226afd6230c97db4fe720e0cca80cb64afd85
  text: - AC-7: DELETE `/students/3/delete` возвращает `200 OK` и текст `Student deleted`.

## Связь SREQ → CREQ
SREQ-0001 → CREQ-B1-013
SREQ-0002 → CREQ-B1-013
SREQ-0010 → CREQ-B1-009
SREQ-0017 → CREQ-B1-014
SREQ-0018 → CREQ-B1-009

## Возможности (полностью)
[CAP-B1-mockmvc_exchange] mockmvc_exchange(jsonBody?:object, method:string, path:string, query?:object) → contentType:string, jsonArray:array, jsonObject:object, status:integer, text:string · adapter=project_native_junit
  src: Контракт композиции для будущего проектного JUnit-теста, а не существующий helper приложения; выполнение этим документом не подтверждается.
  src: Граница: @SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK) с @AutoConfigureMockMvc, реальные контроллеры приложения без заглушек; приложение не хранит состояние, база данных не нужна (pom.xml: только spring-boot-starter-web и spring-boot-starter-test; application.properties без источника данных).
  src: Вызов: MockMvc.perform(MockMvcRequestBuilders.request(HttpMethod.valueOf(method), path)) с .queryParam(name, value) для каждой пары из query (строковое представление значений) и, при наличии jsonBody, .contentType(MediaType.APPLICATION_JSON).content(ObjectMapper.writeValueAsString(jsonBody)); .andReturn().getResponse() даёт MockHttpServletResponse.
  src: Результаты: status = response.getStatus(); contentType = response.getContentType(); text = response.getContentAsString(StandardCharsets.UTF_8) — для текстовых ответов это сам текст, для JSON-ответов это компактная сериализация Jackson без пробелов в порядке геттеров (например {"id":1,"firstName":"Ramseh","lastName":"Mishra"}), по которой проверяется порядок полей; jsonObject и jsonArray — разбор того же текста через ObjectMapper.readValue в Map/List только для ответов с JSON; для текстового ответа они не используются.
  src: Исходники маршрутов: src/main/java/net/javaguides/springboot/controller/StudentController.java (student, students, students/{id}, students/query, students/create, students/{id}/update, students/{id}/delete); src/main/java/net/javaguides/springboot/controller/HelloWorldController.java (/hello-world); модель src/main/java/net/javaguides/springboot/bean/Student.java с конструктором Student(int, String, String) и геттерами; существующий тест src/test/java/net/javaguides/springboot/SpringbootRestApiApplicationTests.java подтверждает @SpringBootTest.
  src: Зависимости из pom.xml: spring-boot-starter-parent 3.4.2 (Java 17), spring-boot-starter-web (Spring MVC, Jackson), spring-boot-starter-test (JUnit 5, spring-test MockMvc, AssertJ, JSONassert).

## Кейсы
[TC-B1-010] Удаление студента по DELETE /students/3/delete возвращает подтверждающий текст
  priority: MEDIUM · categories: positive, functional
  requirements: CREQ-B1-009, CREQ-B1-013
  objective: Убедиться, что запрос на удаление принимается и возвращает фиксированное текстовое сообщение.
  pre: Приложение springboot-rest-api поднято в тестовом контексте Spring Boot (MockMvc), внешние сервисы и база данных не требуются.
  management: components=["StudentController"]; external_links={"issues":[],"pages":[]}; folder="StudentController REST API"
  [STEP-B1-010-01] action: Отправить запрос DELETE /students/3/delete.
    data: Идентификатор в пути: 3. Тело запроса отсутствует.
    call: CAP-B1-mockmvc_exchange
    [INPUT-B1-010-01-1] arg:method = "DELETE" :string
    [INPUT-B1-010-01-2] arg:path = "/students/3/delete" :string
    [EXP-B1-010-01-1] expected: Приложение возвращает текст подтверждения удаления.
      | 
      | HTTP 200 OK
      | Student deleted
      [ASSERT-B1-010-01-1-1] project_result:status equals 200
      [ASSERT-B1-010-01-1-2] project_result:text equals "Student deleted"

[TC-B1-013] Отказ в удалении студента с нечисловым идентификатором в пути DELETE /students/abc/delete
  priority: MEDIUM · categories: negative, functional
  requirements: CREQ-B1-013, CREQ-B1-014
  objective: Убедиться, что нечисловой идентификатор в пути приводит к ошибке клиента, а не к подтверждению удаления.
  pre: Приложение springboot-rest-api поднято в тестовом контексте Spring Boot (MockMvc), внешние сервисы и база данных не требуются.
  management: components=["StudentController"]; external_links={"issues":[],"pages":[]}; folder="StudentController REST API"
  [STEP-B1-013-01] action: Отправить запрос DELETE /students/abc/delete с нечисловым идентификатором в пути.
    data: Идентификатор в пути: abc. Тело запроса отсутствует.
    call: CAP-B1-mockmvc_exchange
    [INPUT-B1-013-01-1] arg:method = "DELETE" :string
    [INPUT-B1-013-01-2] arg:path = "/students/abc/delete" :string
    [EXP-B1-013-01-1] expected: Приложение отклоняет запрос как некорректный; подтверждение удаления не возвращается.
      | 
      | HTTP 400 Bad Request
      [ASSERT-B1-013-01-1-1] project_result:status equals 400
