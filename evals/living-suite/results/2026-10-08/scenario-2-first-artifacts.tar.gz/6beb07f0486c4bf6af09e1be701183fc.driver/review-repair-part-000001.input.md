# Ревью автотестов compact-v1 · TCDOC-step5-java-demo-9340016c r1 · part-000001 (1 из 1)

Инструкции контроллера: Проверь назначенные области этой части: соответствие автотестов кейсам, реальную границу приложения, литералы, привязки и сравнения. Верни только coverage, findings, corrections и required_checks.
Ответ: coverage — строка на каждую область ниже, в этом порядке (area_id, status, refs — 1–3 якоря: [ID] кейса или строка кода L<номер> из этой части; у области кейса хотя бы одна ссылка на сам кейс или строки его метода и хелперов; note до 200 символов). findings — severity, code, related_ids (ID кейсов, проверок, файлов, символов), message до 600 символов; INFO не больше 5. corrections — пусто (ревью автотестов не правит кейсы). lint_dispositions — по каждому [LINT-…] части. required_checks — case_ids/requirement_ids и reason.

## Области ответа
- local-file-FILE-B1-student-controller-pipeline-test — общий код файла FILE-B1-student-controller-pipeline-test: поля, настройка и очистка, фикстуры, хелперы, граница приложения, общее состояние.
- local-TC-B1-007 — кейс TC-B1-007: метод и вызываемые хелперы против шагов, входов, ожиданий и проверок кейса.
- cross-2c0c6a6c4b635ebc — взаимодействия тестов этой части через общий код и состояние: порядок, побочные эффекты, общие хелперы, изоляция данных.

## Все кейсы документа (ID)
TC-B1-007

## Требования CREQ кейсов этой части
[CREQ-B1-006] POST /students/create с полным JSON-телом студента (id, firstName, lastName) возвращает 201 Created и тело, равное телу запроса.
  src: docs/requirements/student-controller.md — 3.5. POST `/students/create`; docs/requirements/student-controller.md — AC-5
[CREQ-B1-013] Проверки выполняются через тестовый стек проекта: JUnit 5 и MockMvc из spring-boot-starter-test, сборка и запуск Maven; это ограничение тестовой работы, а не поведение приложения.
  src: docs/requirements/student-controller.md — заголовок и список источников; docs/requirements/student-controller.md — 1. Общее описание, строка «Стек тестирования»; pom.xml — spring-boot-starter-test

## Возможности (полностью)
[CAP-B1-mockmvc_exchange] mockmvc_exchange(jsonBody?:object, method:string, path:string, query?:object) → contentType:string, jsonArray:array, jsonObject:object, status:integer, text:string · adapter=project_native_junit
  src: Контракт композиции для будущего проектного JUnit-теста, а не существующий helper приложения; выполнение этим документом не подтверждается.
  src: Граница: @SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK) с @AutoConfigureMockMvc, реальные контроллеры приложения без заглушек; приложение не хранит состояние, база данных не нужна (pom.xml: только spring-boot-starter-web и spring-boot-starter-test; application.properties без источника данных).
  src: Вызов: MockMvc.perform(MockMvcRequestBuilders.request(HttpMethod.valueOf(method), path)) с .queryParam(name, value) для каждой пары из query (строковое представление значений) и, при наличии jsonBody, .contentType(MediaType.APPLICATION_JSON).content(ObjectMapper.writeValueAsString(jsonBody)); .andReturn().getResponse() даёт MockHttpServletResponse.
  src: Результаты: status = response.getStatus(); contentType = response.getContentType(); text = response.getContentAsString(StandardCharsets.UTF_8) — для текстовых ответов это сам текст, для JSON-ответов это компактная сериализация Jackson без пробелов в порядке геттеров (например {"id":1,"firstName":"Ramseh","lastName":"Mishra"}), по которой проверяется порядок полей; jsonObject и jsonArray — разбор того же текста через ObjectMapper.readValue в Map/List только для ответов с JSON; для текстового ответа они не используются.
  src: Исходники маршрутов: src/main/java/net/javaguides/springboot/controller/StudentController.java (student, students, students/{id}, students/query, students/create, students/{id}/update, students/{id}/delete); src/main/java/net/javaguides/springboot/controller/HelloWorldController.java (/hello-world); модель src/main/java/net/javaguides/springboot/bean/Student.java с конструктором Student(int, String, String) и геттерами; существующий тест src/test/java/net/javaguides/springboot/SpringbootRestApiApplicationTests.java подтверждает @SpringBootTest.
  src: Зависимости из pom.xml: spring-boot-starter-parent 3.4.2 (Java 17), spring-boot-starter-web (Spring MVC, Jackson), spring-boot-starter-test (JUnit 5, spring-test MockMvc, AssertJ, JSONassert).

## Общий код (SUPPORT), строки исходного файла
[FILE-B1-student-controller-pipeline-test] · src/test/java/net/javaguides/springboot/controller/StudentControllerPipelineTest.java · java/junit5 · 219 строк · sha256:699dfa271baa76f27ac25a654289da5ddf96ab2ce7e658f7624334f318f299bc
L0001| package net.javaguides.springboot.controller;
L0002| 
L0003| import static org.assertj.core.api.Assertions.assertThat;
L0004| 
L0005| import com.fasterxml.jackson.core.type.TypeReference;
L0006| import com.fasterxml.jackson.databind.ObjectMapper;
L0007| import java.nio.charset.StandardCharsets;
L0008| import java.util.LinkedHashMap;
L0009| import java.util.List;
L0010| import java.util.Map;
L0011| import org.junit.jupiter.api.DisplayName;
L0012| import org.junit.jupiter.api.Test;
L0013| import org.springframework.beans.factory.annotation.Autowired;
L0014| import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
L0015| import org.springframework.boot.test.context.SpringBootTest;
L0016| import org.springframework.http.HttpMethod;
L0017| import org.springframework.http.MediaType;
L0018| import org.springframework.mock.web.MockHttpServletResponse;
L0019| import org.springframework.test.web.servlet.MockMvc;
L0020| import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
L0021| import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
L0022| 
L0023| /**
L0024|  * Functional tests of StudentController and HelloWorldController generated by the test-skills
L0025|  * pipeline from the accepted case document TCDOC-step5-java-demo-9340016c revision 1
L0026|  * (cases TC-B1-001 .. TC-B1-012). Every request goes through MockMvc against the real
L0027|  * application context; the application keeps no state, so the context is shared by the class.
L0028|  */
L0029| @SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
L0030| @AutoConfigureMockMvc
L0031| class StudentControllerPipelineTest {
L0032| 
L0033|     private static final String APPLICATION_JSON = "application/json";
L0034| 
L0035|     @Autowired
L0036|     private MockMvc mockMvc;
L0037| 
L0038|     @Autowired
L0039|     private ObjectMapper objectMapper;
L0040| 
L0041|     // --- CAP-B1-mockmvc_exchange: one request, raw response ------------------------------
L0042| 
L0043|     private MockHttpServletResponse exchange(String method, String path, Map<String, String> query,
L0044|                                              Map<String, Object> jsonBody) throws Exception {
L0045|         MockHttpServletRequestBuilder request = MockMvcRequestBuilders.request(HttpMethod.valueOf(method), path);
L0046|         if (query != null) {
L0047|             for (Map.Entry<String, String> entry : query.entrySet()) {
L0048|                 request = request.queryParam(entry.getKey(), entry.getValue());
L0049|             }
L0050|         }
L0051|         if (jsonBody != null) {
L0052|             request = request.contentType(MediaType.APPLICATION_JSON)
L0053|                     .content(objectMapper.writeValueAsString(jsonBody));
L0054|         }
L0055|         return mockMvc.perform(request).andReturn().getResponse();
L0056|     }
L0057| 
L0058|     private static String text(MockHttpServletResponse response) throws Exception {
L0059|         return response.getContentAsString(StandardCharsets.UTF_8);
L0060|     }
L0061| 
L0062|     private Map<String, Object> jsonObject(MockHttpServletResponse response) throws Exception {
L0063|         return objectMapper.readValue(text(response), new TypeReference<Map<String, Object>>() { });
L0064|     }
L0065| 
L0066|     private List<Map<String, Object>> jsonArray(MockHttpServletResponse response) throws Exception {
L0067|         return objectMapper.readValue(text(response), new TypeReference<List<Map<String, Object>>>() { });
L0068|     }
L0069| 
L0070|     private static Map<String, Object> student(Integer id, String firstName, String lastName) {
L0071|         Map<String, Object> student = new LinkedHashMap<>();
L0072|         student.put("id", id);
L0073|         student.put("firstName", firstName);
L0074|         student.put("lastName", lastName);
L0075|         return student;
L0076|     }
L0077| 
L0078|     private static List<Map<String, Object>> fourStudents() {
L0079|         return List.of(
L0080|                 student(1, "Ramesh", "Mishra"),
L0081|                 student(2, "Umesh", "Mishra"),
L0082|                 student(3, "Ram", "Mishra"),
L0083|                 student(4, "Sanjay", "Mishra"));
L0084|     }
L0085| 
L0086|     // --- cases --------------------------------------------------------------------------
L0087| 
L0088|     @Test
L0089|     @DisplayName("TC-B1-001 Получение фиксированного студента по GET /student")
L0090|     void tcB1001GetStudentReturnsFixedStudent() throws Exception {
L0091|         MockHttpServletResponse response = exchange("GET", "/student", null, null);
L0092| 
L0093|         assertThat(response.getStatus()).as("ASSERT-B1-001-01-1-1").isEqualTo(200);
L0094|         assertThat(response.getContentType()).as("ASSERT-B1-001-01-1-2").isEqualTo(APPLICATION_JSON);
L0095|         assertThat(jsonObject(response)).as("ASSERT-B1-001-01-1-3").isEqualTo(student(1, "Ramseh", "Mishra"));
L0096|         assertThat(text(response)).as("ASSERT-B1-001-01-1-4")
L0097|                 .isEqualTo("{\"id\":1,\"firstName\":\"Ramseh\",\"lastName\":\"Mishra\"}");
L0098|     }
L0099| 
L0100|     @Test
L0101|     @DisplayName("TC-B1-002 Получение списка из четырёх студентов по GET /students")
L0102|     void tcB1002GetStudentsReturnsFourStudentsInOrder() throws Exception {
L0103|         MockHttpServletResponse response = exchange("GET", "/students", null, null);
L0104| 
L0105|         assertThat(response.getStatus()).as("ASSERT-B1-002-01-1-1").isEqualTo(200);
L0106|         assertThat(response.getContentType()).as("ASSERT-B1-002-01-1-2").isEqualTo(APPLICATION_JSON);
L0107|         List<Map<String, Object>> students = jsonArray(response);
L0108|         assertThat(students).as("ASSERT-B1-002-01-1-3").hasSize(4);
L0109|         assertThat(students).as("ASSERT-B1-002-01-1-4").isEqualTo(fourStudents());
L0110|     }
L0111| 
L0112|     @Test
L0113|     @DisplayName("TC-B1-003 Получение студента по идентификатору из пути GET /students/5")
L0114|     void tcB1003GetStudentByPathVariableReturnsRequestedId() throws Exception {
L0115|         MockHttpServletResponse response = exchange("GET", "/students/5", null, null);
L0116| 
L0117|         assertThat(response.getStatus()).as("ASSERT-B1-003-01-1-1").isEqualTo(200);
L0118|         assertThat(jsonObject(response)).as("ASSERT-B1-003-01-1-2").isEqualTo(student(5, "Ramsesh", "Mishra"));
L0119|     }
L0120| 
L0121|     @Test
L0122|     @DisplayName("TC-B1-004 Получение студента по идентификатору 0 из пути GET /students/0")
L0123|     void tcB1004GetStudentByPathVariableZeroIsAccepted() throws Exception {
L0124|         MockHttpServletResponse response = exchange("GET", "/students/0", null, null);
L0125| 
L0126|         assertThat(response.getStatus()).as("ASSERT-B1-004-01-1-1").isEqualTo(200);
L0127|         assertThat(jsonObject(response)).as("ASSERT-B1-004-01-1-2").isEqualTo(student(0, "Ramsesh", "Mishra"));
L0128|     }
L0129| 
L0130|     @Test
L0131|     @DisplayName("TC-B1-005 Получение студента по query-параметру GET /students/query?id=7")
L0132|     void tcB1005GetStudentByQueryParameterReturnsRequestedId() throws Exception {
L0133|         MockHttpServletResponse response = exchange("GET", "/students/query", Map.of("id", "7"), null);
L0134| 
L0135|         assertThat(response.getStatus()).as("ASSERT-B1-005-01-1-1").isEqualTo(200);
L0136|         assertThat(jsonObject(response)).as("ASSERT-B1-005-01-1-2").isEqualTo(student(7, "Ramesh", "Mishra"));
L0137|     }
L0138| 
L0139|     @Test
L0140|     @DisplayName("TC-B1-006 Отказ в запросе студента без обязательного параметра id GET /students/query")
L0141|     void tcB1006GetStudentWithoutIdParameterIsBadRequest() throws Exception {
L0142|         MockHttpServletResponse response = exchange("GET", "/students/query", Map.of(), null);
L0143| 
L0144|         assertThat(response.getStatus()).as("ASSERT-B1-006-01-1-1").isEqualTo(400);
L0145|     }
L0146| 
L0158| 
L0159|     @Test
L0160|     @DisplayName("TC-B1-008 Создание студента с частично заполненным телом без lastName POST /students/create")
L0161|     void tcB1008CreateStudentWithoutLastNameEchoesNull() throws Exception {
L0162|         Map<String, Object> body = new LinkedHashMap<>();
L0163|         body.put("id", 6);
L0164|         body.put("firstName", "Olga");
L0165| 
L0166|         MockHttpServletResponse response = exchange("POST", "/students/create", null, body);
L0167| 
L0168|         assertThat(response.getStatus()).as("ASSERT-B1-008-01-1-1").isEqualTo(201);
L0169|         assertThat(jsonObject(response)).as("ASSERT-B1-008-01-1-2").isEqualTo(student(6, "Olga", null));
L0170|     }
L0171| 
L0172|     @Test
L0173|     @DisplayName("TC-B1-009 Обновление студента по PUT /students/10/update возвращает тело без подстановки id из пути")
L0174|     void tcB1009UpdateStudentEchoesBodyWithoutPathId() throws Exception {
L0175|         Map<String, Object> body = student(42, "Anna", "Sidorova");
L0176| 
L0177|         MockHttpServletResponse response = exchange("PUT", "/students/10/update", null, body);
L0178| 
L0179|         assertThat(response.getStatus()).as("ASSERT-B1-009-01-1-1").isEqualTo(200);
L0180|         assertThat(jsonObject(response)).as("ASSERT-B1-009-01-1-2").isEqualTo(student(42, "Anna", "Sidorova"));
L0181|     }
L0182| 
L0183|     @Test
L0184|     @DisplayName("TC-B1-010 Удаление студента по DELETE /students/3/delete возвращает подтверждающий текст")
L0185|     void tcB1010DeleteStudentReturnsConfirmationText() throws Exception {
L0186|         MockHttpServletResponse response = exchange("DELETE", "/students/3/delete", null, null);
L0187| 
L0188|         assertThat(response.getStatus()).as("ASSERT-B1-010-01-1-1").isEqualTo(200);
L0189|         assertThat(text(response)).as("ASSERT-B1-010-01-1-2").isEqualTo("Student Successfully Deleted!");
L0190|     }
L0191| 
L0192|     @Test
L0193|     @DisplayName("TC-B1-011 Получение приветствия по GET /hello-world")
L0194|     void tcB1011HelloWorldReturnsGreeting() throws Exception {
L0195|         MockHttpServletResponse response = exchange("GET", "/hello-world", null, null);
L0196| 
L0197|         assertThat(response.getStatus()).as("ASSERT-B1-011-01-1-1").isEqualTo(200);
L0198|         assertThat(text(response)).as("ASSERT-B1-011-01-1-2").isEqualTo("Hello World!");
L0199|     }
L0200| 
L0201|     @Test
L0202|     @DisplayName("TC-B1-012 Неизменность списка студентов после создания студента")
L0203|     void tcB1012StudentListIsUnchangedAfterCreate() throws Exception {
L0204|         // STEP-B1-012-01
L0205|         MockHttpServletResponse created = exchange("POST", "/students/create", null, student(9, "Pavel", "Orlov"));
L0206|         assertThat(created.getStatus()).as("ASSERT-B1-012-01-1-1").isEqualTo(201);
L0207|         assertThat(jsonObject(created)).as("ASSERT-B1-012-01-1-2").isEqualTo(student(9, "Pavel", "Orlov"));
L0208| 
L0209|         // STEP-B1-012-02
L0210|         MockHttpServletResponse afterCreate = exchange("GET", "/students", null, null);
L0211|         assertThat(afterCreate.getStatus()).as("ASSERT-B1-012-02-1-1").isEqualTo(200);
L0212|         assertThat(jsonArray(afterCreate)).as("ASSERT-B1-012-02-1-2").isEqualTo(fourStudents());
L0213| 
L0214|         // STEP-B1-012-03
L0215|         MockHttpServletResponse repeated = exchange("GET", "/students", null, null);
L0216|         assertThat(repeated.getStatus()).as("ASSERT-B1-012-03-1-1").isEqualTo(200);
L0217|         assertThat(jsonArray(repeated)).as("ASSERT-B1-012-03-1-2").isEqualTo(fourStudents());
L0218|     }
L0219| }

Таблица общего состояния (построена кодом):
Общих изменяемых полей нет (только константы и поля экземпляра с жизненным циклом PER_METHOD).

## Кейсы и их методы
[TC-B1-007] Создание студента с полным JSON-телом POST /students/create
  requirements: CREQ-B1-006, CREQ-B1-013
  objective: Убедиться, что полностью заполненное тело принимается со статусом 201 и возвращается без изменений.
  pre: Приложение springboot-rest-api поднято в тестовом контексте Spring Boot (MockMvc), внешние сервисы и база данных не требуются.
  [STEP-B1-007-01] action: Отправить запрос POST /students/create с JSON-телом студента.
    call: CAP-B1-mockmvc_exchange
    [INPUT-B1-007-01-1] arg:method = "POST" :string
    [INPUT-B1-007-01-2] arg:path = "/students/create" :string
    [INPUT-B1-007-01-3] arg:jsonBody = {"firstName":"Ivan","id":5,"lastName":"Petrov"} :object
    [EXP-B1-007-01-1] expected: Приложение подтверждает создание и возвращает тот же объект, что был отправлен.
      | 
      | HTTP 201 Created
      | {
      |   "id": 5,
      |   "firstName": "Ivan",
      |   "lastName": "Petrov"
      | }
      [ASSERT-B1-007-01-1-1] project_result:status equals 201
      [ASSERT-B1-007-01-1-2] project_result:jsonObject equals {"firstName":"Ivan","id":5,"lastName":"Petrov"}
  код SYMBOL-B1-007 · FILE-B1-student-controller-pipeline-test · tcB1007CreateStudentEchoesFullBodyWithCreated L147–L157 · хелперы (в общем коде): exchange L43–L56, text L58–L60, jsonObject L62–L64, student L70–L76
L0147|     @Test
L0148|     @DisplayName("TC-B1-007 Создание студента с полным JSON-телом POST /students/create")
L0149|     void tcB1007CreateStudentEchoesFullBodyWithCreated() throws Exception {
L0150|         net.javaguides.springboot.bean.StudentDto request = new net.javaguides.springboot.bean.StudentDto(5, "Ivan", "Petrov");
L0151|         Map<String, Object> body = new ObjectMapper().convertValue(request, new TypeReference<Map<String, Object>>() {});
L0152| 
L0153|         MockHttpServletResponse response = exchange("POST", "/students/create", null, body);
L0154| 
L0155|         assertThat(response.getStatus()).as("ASSERT-B1-007-01-1-1").isEqualTo(201);
L0156|         assertThat(jsonObject(response)).as("ASSERT-B1-007-01-1-2").isEqualTo(student(5, "Ivan", "Petrov"));
L0157|     }
