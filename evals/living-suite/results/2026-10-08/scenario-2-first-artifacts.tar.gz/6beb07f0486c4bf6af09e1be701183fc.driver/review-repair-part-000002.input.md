# Ревью кейсов compact-v1 · TCDOC-step5-java-demo-9340016c r1 · part-000002 (проверка)

Инструкции контроллера: Проверь назначенные области этой части: соответствие автотестов кейсам, реальную границу приложения, литералы, привязки и сравнения. Верни только coverage, findings, corrections и required_checks.
Ответ: coverage — строка на каждую область ниже, в этом порядке (area_id, status CHECKED|UNCHECKED, refs — 1–3 якоря [ID] из этой части, у области кейса хотя бы один якорь самого кейса; строки исходника — SRC-n:Lk; note — до 200 символов). findings — severity, code, related_ids, message (до 600 символов; INFO не больше 5). corrections — target_id, field из словаря, before, after, why. lint_dispositions — по каждому [LINT-…] этой части. required_checks — case_ids/requirement_ids и reason.

## Области ответа
- cross-f82256dafb28d47b9d6f03c1c76e3753acf72f4243e40d6399e364cb68bbe8bb — проверка: Подтвердить по заявленным файлам проекта, существует ли net.javaguides.springboot.bean.StudentDto (конструктор (int,String,String), JSON-свойства id/firstName/lastName без @JsonIgnore); в источниках части заявлен только bean/Student.java. Без этого компиляция метода и состав тела не гарантированы.
Вопрос проверки: Подтвердить по заявленным файлам проекта, существует ли net.javaguides.springboot.bean.StudentDto (конструктор (int,String,String), JSON-свойства id/firstName/lastName без @JsonIgnore); в источниках части заявлен только bean/Student.java. Без этого компиляция метода и состав тела не гарантированы.

## Индекс всех кейсов документа
TC-B1-007 · CREQ-B1-006, CREQ-B1-013 · Создание студента с полным JSON-телом POST /students/create

## Требования CREQ кейсов этой части
[CREQ-B1-006] POST /students/create с полным JSON-телом студента (id, firstName, lastName) возвращает 201 Created и тело, равное телу запроса.
  src: docs/requirements/student-controller.md — 3.5. POST `/students/create`; docs/requirements/student-controller.md — AC-5
[CREQ-B1-013] Проверки выполняются через тестовый стек проекта: JUnit 5 и MockMvc из spring-boot-starter-test, сборка и запуск Maven; это ограничение тестовой работы, а не поведение приложения.
  src: docs/requirements/student-controller.md — заголовок и список источников; docs/requirements/student-controller.md — 1. Общее описание, строка «Стек тестирования»; pom.xml — spring-boot-starter-test

## Возможности (сигнатуры)
[CAP-B1-mockmvc_exchange] mockmvc_exchange(jsonBody?:object, method:string, path:string, query?:object) → contentType:string, jsonArray:array, jsonObject:object, status:integer, text:string · adapter=project_native_junit

## Кейсы
[TC-B1-007] Создание студента с полным JSON-телом POST /students/create
  priority: HIGH · categories: positive, functional
  requirements: CREQ-B1-006, CREQ-B1-013
  objective: Убедиться, что полностью заполненное тело принимается со статусом 201 и возвращается без изменений.
  pre: Приложение springboot-rest-api поднято в тестовом контексте Spring Boot (MockMvc), внешние сервисы и база данных не требуются.
  management: components=["StudentController"]; external_links={"issues":[],"pages":[]}; folder="StudentController REST API"
  [STEP-B1-007-01] action: Отправить запрос POST /students/create с JSON-телом студента.
    data: {
      |   "id": 5,
      |   "firstName": "Ivan",
      |   "lastName": "Petrov"
      | }
    call: CAP-B1-mockmvc_exchange
    [INPUT-B1-007-01-1] arg:method = "POST" :string
    [INPUT-B1-007-01-2] arg:path = "/students/create" :string
    [INPUT-B1-007-01-3] arg:jsonBody = {"firstName":"Ivan","id":5,"lastName":"Petrov"} :object
    [EXP-B1-007-01-1] expected: Приложение подтверждает создание и возвращает тот же объект, что был отправлен.
      | 
      | HTTP 201 Created
      | {
      |   "id": 5,
      |   "firstName": "Ivan",
      |   "lastName": "Petrov"
      | }
      [ASSERT-B1-007-01-1-1] project_result:status equals 201
      [ASSERT-B1-007-01-1-2] project_result:jsonObject equals {"firstName":"Ivan","id":5,"lastName":"Petrov"}
